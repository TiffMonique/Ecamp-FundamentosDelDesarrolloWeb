$(document).ready(function () {

    $.ajax({
        type: "GET",
        url: "https://digimon-api.herokuapp.com/api/digimon",

        dataType: "json",

        success: function (data) {
            $.each(data, function (i, item) {

                var row = "<tr>" +
                    "<td>" + item.name + "</td>" +
                    "<td>" + item.level + "</td>" +
                    "</tr>";

                $("#tabla>tbody").append(row);

            });
        },

    });


});


fetch("https://digimon-api.herokuapp.com/api/digimon").then((res) => res.json())
    .then((data) => {
        data.results.array.forEach((element) => {
            $("#body").append(

                `
                <tr>
                <td>${element.name}</td>
                <td>${element.level}</td>
                </tr>
                
                `
            )

        });
    })

/*$('.tablemanager').tablemanager({
    firstSort: [[3, 0], [2, 0], [1, 'asc']],
    disable: ["last"],
    appendFilterby: true,
    debug: true,
    vocabulary: {
        voc_filter_by: 'Filter by',
        voc_type_here_filter: 'Filter...',
        voc_show_rows: 'filas por pagina'
    },
    pagination: true,
    showrows: [5, 10, 20, 50, 100],
    disableFilterBy: [1]
});
*/


/*====PAGINACION==================================================
==================================================================
*/


function simpleTemplating(data) {
    var html1 = '<ul>';
    $.each(data, function (index, item) {
        html1 += '<li>' + item + '</li>';
    });
    html1 += '</ul>';
    return html1;
}


$('#pagination-container').pagination({
    dataSource: [1, 2, 3, 4, 5, 6, 7, ... 15],
    callback: function (data, pagination) {
        var html = simpleTemplating(data);
        $('#data-container').html(html);
    }
})